from .. import Provider as SsnProvider


class Provider(SsnProvider):
    ssn_formats = ("############",)
