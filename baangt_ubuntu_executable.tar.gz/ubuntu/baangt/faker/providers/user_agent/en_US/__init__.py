from .. import Provider as UserAgentProvider


class Provider(UserAgentProvider):
    pass
