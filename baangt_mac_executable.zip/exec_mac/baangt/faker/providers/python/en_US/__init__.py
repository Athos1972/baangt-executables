from .. import Provider as PythonProvider


class Provider(PythonProvider):
    pass
