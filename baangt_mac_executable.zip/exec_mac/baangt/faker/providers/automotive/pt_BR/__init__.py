from .. import Provider as AutomotiveProvider


class Provider(AutomotiveProvider):

    license_formats = (
        '???-####',
    )
